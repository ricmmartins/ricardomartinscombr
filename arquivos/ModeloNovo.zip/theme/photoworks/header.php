<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link href="<?php bloginfo('template_directory'); ?>/slideshow.css" rel="stylesheet" type="text/css" />
<link href="<?php bloginfo('template_directory'); ?>/slimbox2.css" rel="stylesheet" type="text/css" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>

<!--[if IE 6]>
<script src="<?php bloginfo('stylesheet_directory'); ?>/js/DD_belatedPNG.js"></script>
<script>
  DD_belatedPNG.fix('img, #twitter, #information, #thumbnails, #slideleft, #slideright');
</script>
<![endif]--> 
<?php wp_head(); ?>

<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript" language="javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.dropdownPlain.js"></script>
<script type="text/javascript" language="javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/slimbox2.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.flow.1.2.auto.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$("#myController").jFlow({
		slides: "#slides",
		controller: ".jFlowControl", // must be class, use . sign
		slideWrapper : "#jFlowSlide", // must be id, use # sign
		selectedWrapper: "jFlowSelected",  // just pure text, no sign
		auto: true,		//auto change slide, default true
		width: "960px",
		height: "400px",
		duration: 400,
		prev: ".jFlowPrev", // must be class, use . sign
		next: ".jFlowNext" // must be class, use . sign
	});
});
</script>
</head>
<body>
	<div id="container">
		<div class="centercolumn">
		<!-- BEGIN HEADER -->
			<div id="header">
				<div id="top">
					<div id="topleft">
					<?php
						$logotype = get_option('photoworks_logo_type');
						$logoimage = get_option('photoworks_logo_image'); 
						$sitename = get_option('photoworks_site_name');
						$tagline = get_option('photoworks_tagline');
						$menu = get_option('photoworks_menu');
						if($logoimage == ""){ $logoimage = get_bloginfo('stylesheet_directory') . "/images/logo.png"; }
					?>
						<div id="logo">
							<?php if($logotype ==0 || $logotype == ""){ ?>
							<?php if($sitename=="" && $tagline==""){?>
		
								<div class="logo">
									<h1><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
									<span class="desc"><?php bloginfo('description'); ?></span>
								</div>
								<?php }else{ ?>
								<div class="logo">
										<h1><a href="<?php echo get_option('home'); ?>/"><?php echo $sitename; ?></a></h1>
										<span class="desc"><?php echo $tagline; ?></span>
								</div>
								<?php }?>
								<?php }else{ ?>
								<div id="logoimg">
									<a href="<?php echo get_option('home'); ?>/"><img src="<?php echo $logoimage; ?>" alt="<?php bloginfo('name'); ?>" border="0" /></a>
								</div>
							<?php }?>
						</div>
						<!-- end logo -->
					</div><!-- end topleft -->
					<div id="topright">
					<?php
					$twitterstatus= get_option('photoworks_twitter_status');
					 if($twitterstatus == 0 || $twitterstatus == "") { ?>
						<div id="twitter">
							<div id="twitter_text">
							<script type="text/javascript" src="http://twitter.com/javascripts/blogger.js"></script>
							<?php $username = get_option('photoworks_twitter');?>
							<?php if($username==""){?>
							<?php wp_echoTwitter('templatesquare');?>
							<?php }else{?>
							<?php wp_echoTwitter($username);?>
							<?php } ?>
							</div>
						</div><!-- end twitter -->
					 <?php } ?>
					</div><!-- end topright -->
				</div><!-- end top -->
			<div id="mainmenu">
				<div id="nav_container">
				<?php $menu = get_option('photoworks_menu'); ?>
				<ul class="dropdown">
					<li class="page_item<?php if (is_front_page()) echo ' current_page_item'; ?>">
							<a href="<?php echo get_option('home'); ?>/"><span>Home</span></a>
						</li>
					<?php wp_list_pages('title_li=0&link_before=<span>&link_after=</span>&sort_column=menu_order&' . $menu); ?>
				</ul><!-- end menu -->	
				</div>
			</div><!-- end mainmenu -->
			<?php if(is_front_page() ) { ?>
			<div id="container-slider">
				<?php include('slideshow.php');?>
			</div><!-- end content-slider -->
			<?php }?>
			</div>
		<!-- END HEADER -->
