	<div class="clr"></div><!-- clear float -->
	
	<!-- BEGIN FOOTER -->
	<div id="container-bottom">
		<div id="footer">
		<?php $footertext = stripslashes(get_option('photoworks_footer'));?>
		<?php if($footertext==""){?>
		<?php _e('Copyright &copy;');?>
		<?php
		global $wpdb;
	$post_datetimes = $wpdb->get_results("SELECT YEAR(min(post_date_gmt)) AS firstyear, YEAR(max(post_date_gmt)) AS lastyear FROM $wpdb->posts WHERE post_date_gmt > 1970");
	if ($post_datetimes) {
		$firstpost_year = $post_datetimes[0]->firstyear;
		$lastpost_year = $post_datetimes[0]->lastyear;

		$copyright = $firstpost_year;
		if($firstpost_year != $lastpost_year) {
			$copyright .= '-'. $lastpost_year;
		}
		$copyright .= ' ';

		echo $copyright;
		bloginfo('name');
			}
		?>.&nbsp;<?php _e('All rights reserved.
		  Powered by <a href="http://wordpress.org">WordPress</a>   |  Theme by  <a href="http://www.templatesquare.com">TemplateSquare.com</a>');?>

		<?php }else{?>
		<?php echo $footertext; ?>
		<?php } ?>

		</div>
	</div><!-- end container-bottom -->
	<!-- END FOOTER -->
<?php wp_footer(); ?>
<?php $google = stripslashes(get_option('photoworks_google'));?>
<?php if($google==""){?>
<?php }else{?>
<?php echo $google; ?>
<?php } ?>
</body>
</html>
