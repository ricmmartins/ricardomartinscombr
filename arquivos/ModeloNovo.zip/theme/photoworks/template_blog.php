<? /*
Template Name: Template Blog
*/
?>

<?php get_header(); ?>
		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_blog_top.php'); ?></div>
			<div id="header_inner_right">
			<h1 class="title">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php the_title(); ?>
			<?php endwhile; endif; ?>
			<?php wp_reset_query();?>
			</h1>
			</div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft">
				<div id="maincontent">
					<?php $values = get_post_custom_values("category-include"); $cat=$values[0];  ?>
					<?php global $more;	$more = 0;?>
					<?php $wp_query = new WP_Query(); ?>
					<?php $strinclude = $cat;?>
					<?php $catinclude = 'cat=' . $strinclude ;?>
					<?php $wp_query->query('&' . $catinclude .' &paged='.$paged); ?>
					
					<?php  if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post(); ?>	
					<div <?php post_class() ?>>
						<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><small><span class="info"><?php the_time('F jS, Y') ?> by <?php the_author() ?> | <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></span></small>
						<div class="entry_blog">
						<?php the_content('Read more...'); ?>
						</div><!-- end entry -->
					</div>
					<?php endwhile; endif; ?>
					<?php wp_reset_query();?>
					<div class="navigation">
						<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
						<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
					</div>
				</div><!-- end maincontent -->
			</div><!-- end contentleft -->
			<div id="side">
			<div class="sidebox">
				<div class="sidebox-bgtop">
				<div class="sidebox-bgbottom">
				<div class="sidebox-padding">
					<?php include('sidebar/sidebar_blog_right.php'); ?>
				</div><!-- end sidebox padding -->
				</div><!-- end sidebox bgbottom -->
				</div><!-- end sidebox bgtop -->
			</div><!-- end sidebox -->
			</div><!-- end side -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
<?php get_footer(); ?>
