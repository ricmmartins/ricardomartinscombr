
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(4) ) : ?>

				<li><h2>Sidebar About Left</h2>
					<ul>
						<li>This is sidebar about left. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

