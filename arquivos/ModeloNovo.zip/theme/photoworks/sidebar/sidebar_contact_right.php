
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(11) ) : ?>

				<li><h2>Sidebar Contact Right</h2>
					<ul>
						<li>This is sidebar contact right. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

