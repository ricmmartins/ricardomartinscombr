
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(15) ) : ?>

				<li><h2>Sidebar Extra2 Right</h2>
					<ul>
						<li>This is sidebar extra2 right. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

