
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(13) ) : ?>

				<li><h2>Sidebar Extra1 Right</h2>
					<ul>
						<li>This is sidebar extra1 right. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

