
	<div id="sidebar">
		<ul>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(2) ) : ?>

				<li><h2>Sidebar Home Right</h2>
					<ul>
						<li>This is sidebar home right. Change this sidebar via wordpress admin under Appearance - Widgets</li>
					</ul>
				</li>

			<?php endif; ?>
		</ul>
		
	</div>

