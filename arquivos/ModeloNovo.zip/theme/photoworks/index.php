<?php get_header(); ?>

		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
			<div id="content">
				<div id="contentleft">
					<div id="maincontent">
					<?php if (have_posts()) : ?>
				
						<?php while (have_posts()) : the_post(); ?>
				
							<div <?php post_class() ?> id="post-<?php the_ID(); ?>">
								<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><small><span class="info"><?php the_time('F jS, Y') ?> by <?php the_author() ?> | <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></span></small>
				
								<div class="entry_blog">
									<?php the_content('Read more...'); ?>
								</div>
							</div>
				
						<?php endwhile; ?>
				
						<div class="navigation">
							<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
							<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
						</div>
				
					<?php else : ?>
				
						<h2 class="center">Not Found</h2>
						<p class="center">Sorry, but you are looking for something that isn't here.</p>
						<?php get_search_form(); ?>
				
					<?php endif; ?>
					</div><!-- end maincontent -->
				</div><!-- end contentleft -->
				<div id="side">
				<div class="sidebox">
					<div class="sidebox-bgtop">
					<div class="sidebox-bgbottom">
					<div class="sidebox-padding">
						<?php include('sidebar/sidebar_blog_right.php'); ?>
					</div><!-- end sidebox padding -->
					</div><!-- end sidebox bgbottom -->
					</div><!-- end sidebox bgtop -->
				</div><!-- end sidebox -->
				</div><!-- end side -->
				<div class="clr"></div><!-- clear float -->
			</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
	
<?php get_footer(); ?>
