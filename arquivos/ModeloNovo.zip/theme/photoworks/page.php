<?php get_header(); ?>
		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_blog_top.php'); ?></div>
			<div id="header_inner_right"><h1 class="title"><?php the_title(); ?></h1></div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft">
				<div id="maincontent">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="post" id="post-<?php the_ID(); ?>">
							<div class="entry">
								<?php the_content('Read more...'); ?>
				
								<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				
							</div>
						</div>
						<?php endwhile; endif; ?>
					<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
					
					<?php comments_template(); ?>
				</div><!-- end maincontent -->
			</div><!-- end contentleft -->
			<div id="side">
			<div class="sidebox">
				<div class="sidebox-bgtop">
				<div class="sidebox-bgbottom">
				<div class="sidebox-padding">
					<?php include('sidebar/sidebar_blog_right.php'); ?>
				</div><!-- end sidebox padding -->
				</div><!-- end sidebox bgbottom -->
				</div><!-- end sidebox bgtop -->
			</div><!-- end sidebox -->
			</div><!-- end side -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
<?php get_footer(); ?>
