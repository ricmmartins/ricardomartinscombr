<?php 
/*
Template Name: Template Home
*/
get_header(); ?>

		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft">
				<div id="maincontent">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<?php global $more;	$more = 0;?>
						<div class="post" id="post-<?php the_ID(); ?>">
						<h2><?php the_title(); ?></h2>
							<div class="entry">
								<?php the_content('Read more...'); ?>
				
								<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				
							</div>
						</div>
						<?php endwhile; endif; ?>
						<br />
						<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
					
				</div><!-- end maincontent -->
			</div><!-- end contentleft -->
			<div id="side">
			<div class="sidebox">
				<div class="sidebox-bgtop">
				<div class="sidebox-bgbottom">
				<div class="sidebox-padding">
					<?php include('sidebar/sidebar_home_right.php'); ?>
				</div><!-- end sidebox padding -->
				</div><!-- end sidebox bgbottom -->
				</div><!-- end sidebox bgtop -->
			</div><!-- end sidebox -->
			</div><!-- end side -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
	
<?php get_footer(); ?>
