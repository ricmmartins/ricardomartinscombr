			<?php 
			$getcat = get_option('photoworks_slider_category');
			if($getcat=="" || $getcat=="All Categories"){ $querycat = "&category_name=slideshow"; }else{ $querycat = "&category_name=" . $getcat; }
			?>
			<ul id="slideshow">
				<?php query_posts("showposts=-1" . $querycat);?>
				<?php while (have_posts()) : the_post(); ?>	
					<li>
					<span>
						<?php $values = get_post_custom_values("image");?>
						<?php echo $values[0];?>
					</span>
					<h3><?php the_title(); ?></h3>
					<p><?php $excerpt = get_the_excerpt();
					echo string_limit_words($excerpt,470).'...';
					?></p>
					<a href="#"><img src="<?php echo bloginfo('template_url'); ?>/scripts/timthumb.php?src=/<?php
$values = get_post_custom_values("image"); echo $values[0]; ?>&amp;w=97&amp;h=56&amp;zc=1&amp;q=100"
alt="<?php the_title(); ?>" class="left" width="97px" height="56px"  /></a>
						
					</li>
				<?php endwhile; ?>
				<?php wp_reset_query();?>
			</ul>
			<div id="wrapper">
				<div id="fullsize">
					<div id="imgprev" class="imgnav" title="Previous Image"></div>
					<div id="imglink"></div>
					<div id="imgnext" class="imgnav" title="Next Image"></div>
					<div id="image"></div>
					<div id="information">
						<h3></h3>
						<p></p>
					</div>
				</div>
				<div id="thumbnails">
					<div id="slideleft" title="Slide Left"></div>
					<div id="slidearea">
						<div id="slider"></div>
					</div>
					<div id="slideright" title="Slide Right"></div>
				</div>
			</div>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/slideshow.js"></script>
		<?php
			$slidespeed=get_option('photoworks_slider_speed');
			$slidescrollspeed=get_option('photoworks_slider_scroll_speed');
		 ?>
		<script type="text/javascript">
		<!-- 
			$j('slideshow').style.display='none';
			$j('wrapper').style.display='block';
			var slideshow=new TINY.slideshow("slideshow");
			window.onload=function(){
				slideshow.auto=true;
				
				<?php if($slidespeed == "" || $slidespeed == 0 ) { ?>
				slideshow.speed=5;
				<?php }else{ ?>
				slideshow.speed=<?php echo $slidespeed; ?>;
				<?php } ?>
				
				slideshow.link="linkhover";
				slideshow.info="information";
				slideshow.thumbs="slider";
				slideshow.left="slideleft";
				slideshow.right="slideright";
				
				<?php if($slidespeed == "" || $slidespeed == 0 ) { ?>
				slideshow.scrollSpeed=14;
				<?php }else{ ?>
				slideshow.scrollSpeed=<?php echo $slidescrollspeed; ?>;
				<?php } ?>
				
				slideshow.spacing=25;
				slideshow.active="#fff";
				slideshow.init("slideshow","image","imgprev","imgnext","imglink");
			}
		//-->  
		</script>
