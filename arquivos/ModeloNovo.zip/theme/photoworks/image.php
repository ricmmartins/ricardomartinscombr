<?php get_header();?>
		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_blog_top.php'); ?></div>
			<div id="header_inner_right"><h1 class="title"><?php the_category(', ')?></h1></div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft">
				<div id="maincontent">
					  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<div class="post" id="post-<?php the_ID(); ?>">
								<h2><a href="<?php echo get_permalink($post->post_parent); ?>" rev="attachment"><?php echo get_the_title($post->post_parent); ?></a> &raquo; <?php the_title(); ?></h2>
								<div class="entry_blog">
									<p class="attachment"><a href="<?php echo wp_get_attachment_url($post->ID); ?>"><?php echo wp_get_attachment_image( $post->ID, 'medium' ); ?></a></p>
									<div class="caption"><?php if ( !empty($post->post_excerpt) ) the_excerpt(); // this is the "caption" ?></div>
					
									<?php the_content('Read more...'); ?>
					
									<div class="navigation">
										<div class="alignleft"><?php previous_image_link() ?></div>
										<div class="alignright"><?php next_image_link() ?></div>
									</div>
									<br class="clear" />
									<br class="clear" />
								</div>
					
							</div>
					
						<?php comments_template(); ?>
					
						<?php endwhile; else: ?>
					
							<p>Sorry, no attachments matched your criteria.</p>
					
					<?php endif; ?>
				</div><!-- end maincontent -->
			</div><!-- end contentleft -->
			<div id="side">
			<div class="sidebox">
				<div class="sidebox-bgtop">
				<div class="sidebox-bgbottom">
				<div class="sidebox-padding">
					<?php include('sidebar/sidebar_blog_right.php'); ?>
				</div><!-- end sidebox padding -->
				</div><!-- end sidebox bgbottom -->
				</div><!-- end sidebox bgtop -->
			</div><!-- end sidebox -->
			</div><!-- end side -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
<?php get_footer(); ?>
