<?php 
/*
Template Name: Template Gallery
*/
get_header(); ?>
		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_gallery_top.php'); ?></div>
			<div id="header_inner_right">
			<h1 class="title">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<?php $values = get_post_custom_values("category-include"); $cat=$values[0];  ?>
					<?php if(get_the_title()!=get_the_title($post->post_parent)) {echo get_the_title($post->post_parent) . ' - '; } ?>
					<?php the_title();  ?>
					<?php endwhile; endif; ?>
					<?php wp_reset_query();?>
					
			</h1></div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
			<div id="contentleft-full">
				<div id="maincontent-full">
				<div class="portfolio-slider">
						<div id="myController">
							<?php 
								$categories = get_categories('include=' . $cat);
								foreach ($categories as $value) {
									echo '<span class="jFlowControl">' . $value -> cat_name . '</span>';
								}
							?>
						</div><!-- end myController -->
						
						
						<?php 
							$categories = get_categories('include=' . $cat);
							echo '<div id="slides">'; 
							$i=1;
							foreach ($categories as $value) {	
								echo '<div class="slide-wrapper">';						
								$wp_query->query('&cat=' . get_cat_ID( $value -> cat_name ) . '&showpost=8');
								
								if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post();
									$values = get_post_custom_values("image");
								if(($i%4) == 0){
									$addclass = "nomargin";
								}	
							?>
									<div class="box_pf <?php echo $addclass; ?>">
										<a href="<?php echo $values[0];?>" rel="lightbox-gallery" title="<?php the_title(); ?>"><img src="<?php echo bloginfo('template_url'); ?>/scripts/timthumb.php?src=/<?php echo $values[0];?>&amp;w=220&amp;h=146&amp;zc=1&amp;q=100"
									alt="<?php the_title();  ?>" width="220px" height="146px"  /></a>
									</div>
							<?php
								$i++; $addclass = "";
								endwhile; endif;
								wp_reset_query();
								
								echo '</div>';
							}
							echo '</div>';
						?>

				</div><!-- end portfolio-slider -->		
				</div><!-- end maincontent full -->
			</div><!-- end contentleft -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->

<?php get_footer(); ?>
