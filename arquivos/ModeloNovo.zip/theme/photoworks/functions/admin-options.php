<?php

// Theme Setting
	$themename 				= "Photoworks";
	$shortname 				= "photoworks";
	
// Options panel
	

		
// Setting header
$options = array (

				array(	"name" => "Header",
											"type" => "heading",
											"desc" => "Header Settings"),
											
				array(	"name" => "Logo Type",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Select logo type.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"option1" => "Text-based logo",
											"option2" => "Image logo",
											"value1" => "0",
											"value2" => "1",
											"id" => $shortname."_logo_type",
											"std" => "",
											"type" => "select-custom"),	
											
				array(	"name" => "Info",
											"desc" => "<br>If text-based logo is activated, enter the blog title and tagline in the fields below.",
											"std" => "",
											"type" => "info"),								
								
				array(	"name" => "Site name",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'If text-based logo is activated, enter the blog title here.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_site_name",
											"std" => "",
											"type" => "text"),												
											
				array(	"name" => "Tagline",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'If text-based logo is activated, enter few words about this blog here.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_tagline",
											"std" => "",
											"type" => "text"),	
											
				array(	"name" => "Info",
											"desc" => "<br>If image logo is activated, enter the logo image url (http://www.fullurl.com/logo.png).",
											"std" => "",
											"type" => "info"),
											
				array(	"name" => "Logo Image URL",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'If image logo is activated, enter logo image url here.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_logo_image",
											"std" => "",
											"type" => "text"),	
											
				array(	"name" => "Info",
											"desc" => "<br><strong>Twitter setting.</strong>",
											"std" => "",
											"type" => "info"),	
											
				array(	"name" => "Enable or Disable Twitter",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Enable or disable twitter.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"option1" => "Enable",
											"option2" => "Disable",
											"value1" => "0",
											"value2" => "1",
											"id" => $shortname."_twitter_status",
											"std" => "",
											"type" => "select-custom"),			
											
		array(	"name" => "Twitter Username",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Please enter twitter username.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_twitter",
											"std" => "",
											"type" => "text"), 
				array(	"name" => "Bottom",
											"type" => "bottom"),


											
				array(	"name" => "Navigation",
											"type" => "heading",
											"desc" => "Navigation Settings"),
												
				array(	"name" => "Info",
											"desc" => "You can exclude or include the page IDs for top menu. Example: <strong>exclude=1,2</strong> or <strong>include=4,5</strong> .<br><br>",
											"std" => "",
											"type" => "info"),
				array(	"name" => "Top page menu",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'exclude or include page IDs, separated by commas to exclude or include multiple pages in the top menu.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_menu",
											"std" => "",
											"type" => "text"), 
											
				array(	"name" => "Bottom",
											"type" => "bottom"),							
				array(	"name" => "Slider",
											"type" => "heading",
											"desc" => "Homepage Slider Settings"),
				array(	"name" => "Slider Category",
										"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Select the category that you would like to have displayed in the slideshow section on your homepage.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_slider_category",
											"std" => "Select a category:",
											"type" => "select-categories"),
											
		array(	"name" => "Slider Speed",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Please enter number for slider speed. Default is 5\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_slider_speed",
											"std" => "5",
											"type" => "text"), 
											
		array(	"name" => "Slider Scroll Speed",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Please enter number for slider scroll speed. Default is 14\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_slider_scroll_speed",
											"std" => "14",
											"type" => "text"), 
											
			
				array(	"name" => "Bottom",
											"type" => "bottom"),
											
				array(	"name" => "Contact",
											"type" => "heading",
											"desc" => "Contact settings"),
				array( 	"name" => "Info",
					  "desc" => 'This is the settings for contact page template, please enter your email and subject.',
						"type" => "info"),	
		array(	"name" => "Your Email",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Please enter your email.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_email",
											"std" => "",
											"type" => "text"), 
											
		array(	"name" => "Your Subject Email",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Please enter your subject email.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_email_subject",
											"std" => "",
											"type" => "text"),
											
				array(	"name" => "Bottom",
											"type" => "bottom"),


				array(	"name" => "Footer",
											"type" => "heading",
											"desc" => "Footer and Analytics Settings"),
				array(	"name" => "Footer Text",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Enter footer text. Leave blank will show the default footer text.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_footer",
											"std" => "",
											"type" => "textarea"),

											
				array(	"name" => "Google Analytics",
											"desc" => '(<a href="javascript:void(0)" onmouseover="showtip(event, \'Enter google analytics code.\');"
onmouseout="hidetip();">?</a>)<br>
<div id="mktipmsg" class="mktipmsg" ></div>',
											"id" => $shortname."_google",
											"std" => "",
											"type" => "textarea"),											
				array(	"name" => "Bottom",
											"type" => "bottom")



);


		function mytheme_add_admin() {
	    global $themename, $shortname, $options;
	    if ( $_GET['page'] == basename(__FILE__) ) {
	      if ( 'save' == $_REQUEST['action'] ) {
		      foreach ($options as $value) {
		      	update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }
		      foreach ($options as $value) {
		      	if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }
		      header("Location: themes.php?page=admin-options.php&saved=true");
		      die;
	      }
	    }
	    add_theme_page($themename." Options", "Theme Options", 'edit_themes', basename(__FILE__), 'mytheme_admin');
		}
		
		function mytheme_admin() {
	
	    global $themename, $shortname, $options;
	
	    if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
	    
?>

	<div class="wrap">
	<div id="icon-themes" class="icon32"><br></div>
	<h2><?php echo $themename; ?> Options</h2>
	<style type="text/css">
	.mktipmsg {padding: 5px; background-color: #FFF8DC;  border: 1px solid #DEB887; width:180px;font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #6b6b6b; display:none; position:absolute;left:0px;top:0px; }
	table, td {font-size:11px; }
	th {font-weight:normal; padding-left:10px; width:250px;}

	</style>

	<script type="text/javascript">
	/* This tooltip library was created by Mukul Kumar; http://codeeazy.com */
	function showtip(e,message){var x=0;var y=0;var m;var h;if(!e)
	var e=window.event;if(e.pageX||e.pageY){x=e.pageX;y=e.pageY;}
	else if(e.clientX||e.clientY){x=e.clientX+document.body.scrollLeft+document.documentElement.scrollLeft;y=e.clientY+document.body.scrollTop+document.documentElement.scrollTop;}
	m=document.getElementById('mktipmsg');if((y>10)&&(y<450)){m.style.top=y-4+"px";}
	else{m.style.top=y+4+"px";}
	var messageHeigth=(message.length/20)*10+25;if((e.clientY+messageHeigth)>510)
	{m.style.top=y-messageHeigth+"px";}
	if(x<850){m.style.left=x+20+"px";}
	else{m.style.left=x-170+"px";}
	m.innerHTML=message;m.style.display="block";m.style.zIndex=203;}
	function hidetip(){var m;m=document.getElementById('mktipmsg');m.style.display="none";}
	</script>
	<div class="bordertitle">
		<form method="post">
		
		<?php 
			foreach ($options as $value) { 
				if ($value['type'] == "heading") { 
		?>
		<table border="0" style="background-color:#efefef;" cellpadding="0"><tr><td>
		<table class="" style="width:800px; background-color:#FFFFFF; text-align:left; padding:2px;">
		<thead>
		<tr valign="top" style="background-color:#efefef;"> 
		    <th colspan="2" style="border-bottom: 1px solid #efefef; height:26px; vertical-align:middle; padding-left:10px;">
		        <strong><?php echo $value['name']; ?></strong> / 
						<?php echo $value['desc']; ?>
		    </th>
		</tr>
		</thead>
		<?php
				}
				if ($value['type'] == "bottom") { 
		?>
				</table>
				
				</td></tr>
				</table>
				<br />
		<?php
				}
				
				if ($value['type'] == "description") { 
		?>
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
					<span class="setting-description"><?php echo $value['desc']; ?></span>
		    </td>
		</tr>
		<?php
				}
				
				if ($value['type'] == "info") { 
		?>
		<tr valign="top"> 
		    <th scope="row" colspan="2"><span class="setting-description"><?php echo $value['desc']; ?></span></th>

		</tr>
		<?php
				}
				if ($value['type'] == "text") { 
		?>
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
		        <input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" size="<?php echo $value['size']; ?>" /> 
						<span class="setting-description"><?php echo $value['desc']; ?></span>
		    </td>
		</tr>
		<?php
				}
				
				
				if ($value['type'] == "textarea") { 
				
		?>
		
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
			<textarea cols="50" rows="5"  name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php if ( get_settings( $value['id'] ) != "") { echo stripslashes(get_settings($value['id']));; } else { echo $value['std']; } ?></textarea><span class="setting-description"><?php echo $value['desc']; ?></span>

		    </td>
		</tr>
		<?php
				}
				if ($value['type'] == "select-skin") { 
		?>
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
						<select style="width:80px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
               <option <?php if ( get_settings($value['id']) == $value['option1'] ) echo ' selected="selected"'; ?>><?php echo $value['option1'] ?></option>
               <option <?php if ( get_settings($value['id']) == $value['option2'] ) echo ' selected="selected"'; ?>><?php echo $value['option2'] ?></option>
			    <option <?php if ( get_settings($value['id']) == $value['option3'] ) echo ' selected="selected"'; ?>><?php echo $value['option3'] ?></option>
               <option <?php if ( get_settings($value['id']) == $value['option4'] ) echo ' selected="selected"'; ?>><?php echo $value['option4'] ?></option>
			    <option <?php if ( get_settings($value['id']) == $value['option5'] ) echo ' selected="selected"'; ?>><?php echo $value['option5'] ?></option>
           </select><span class="setting-description"><?php echo $value['desc']; ?></span>
		    </td>
		</tr>
		<?php
				}

				if ($value['type'] == "select-custom") { 
		?>
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
						<select style="width:140px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
               <option value="<?php echo $value['value1'] ?>" <?php if ( get_settings($value['id']) == $value['value1'] ) echo ' selected="selected"'; ?>><?php echo $value['option1'] ?></option>
               <option value="<?php echo $value['value2'] ?>" <?php if ( get_settings($value['id']) == $value['value2'] ) echo ' selected="selected"'; ?>><?php echo $value['option2'] ?></option>

           </select> <span class="setting-description"><?php echo $value['desc']; ?></span>
		    </td>
		</tr>
		<?php
				}
				
				if ($value['type'] == "select-categories") { 
				
					$pn_categories_obj = get_categories('hide_empty=0');
					$pn_categories = array();
						
					foreach ($pn_categories_obj as $pn_cat) {
						$pn_categories[$pn_cat->cat_ID] = $pn_cat->cat_name;
					}
					$categories_tmp = array_unshift($pn_categories, "All Categories");
		?>
		<tr valign="top"> 
		    <th scope="row"><?php echo $value['name']; ?>:</th>
		    <td>
		        <select style="width:240px;" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
               <?php foreach ($pn_categories as $option) { ?>
               <option <?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option>
               <?php } ?>
           </select> <span class="setting-description"><?php echo $value['desc']; ?></span>
		    </td>
		</tr>
		<?php
				}	

			}
		?>
		
	</div>
	
	<p class="submit">
	<input name="save" type="submit" class="button-primary" value="Save changes" />    
	<input type="hidden" name="action" value="save" />
	</p>
	</form>
	
	<?php
	}

	add_action('admin_menu', 'mytheme_add_admin');
?>