<?php 
/*
Template Name: Template About
*/
get_header(); ?>
		<div id="header_inner">
			<div id="header_inner_left"><?php include('sidebar/sidebar_about_top.php'); ?></div>
			<div id="header_inner_right"><h1 class="title"><?php the_title(); ?></h1></div>
		</div>
		</div><!-- end centercolumn -->
	</div><!-- end container -->
	
	<!-- BEGIN CONTENT -->
	<div id="container-content">
		<div class="centercolumn">
		<div id="content">
				<div id="maincontent">
				
					<?php while (have_posts()) : the_post(); ?>
					<?php 
					$values = get_post_custom_values("image");
					if (get_post_custom_values("image")) { 
					$col2 = "col2";
					?>
					
					<div class="col1">
					<img src="<?php echo bloginfo('url'); ?>/<?php echo $values[0];?>" alt="<?php the_title(); ?>" width="330px"/>
					</div><!-- end col1 -->
					
					<?php }else{
					$col2 = "col2_large";
					 ?>
					
					<div class="col1_small">
						<div class="sidebox">
							<div class="sidebox-bgtop">
								<div class="sidebox-bgbottom">
									<div class="sidebox-padding">
										<?php include('sidebar/sidebar_about_left.php'); ?>
									</div><!-- end sidebox padding -->
								</div><!-- end sidebox bgbottom -->
							</div><!-- end sidebox bgtop -->
						</div><!-- end sidebox -->
					</div><!-- end col1 small -->
					
					<?php } ?>
					
					<?php endwhile;?>
					<?php wp_reset_query();?>
					
					<div class="<?php echo $col2;?>">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<div class="post" id="post-<?php the_ID(); ?>">
							<div class="entry">
								<?php the_content('Read more...'); ?>
				
								<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
				
							</div>
						</div>
						<?php endwhile; endif; ?>
						<?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?>
						</div><!-- end col2 -->
						
				</div><!-- end maincontent -->
			<div class="clr"></div><!-- clear float -->
		</div><!-- end content -->
		</div><!-- end centercolumn -->
	</div><!-- end container-content -->
	<!-- END CONTENT -->
	
<?php get_footer(); ?>
