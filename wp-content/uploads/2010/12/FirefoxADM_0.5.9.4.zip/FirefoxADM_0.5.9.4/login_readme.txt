FirefoxADM Login 0.6
--------------------

(Code written by Mark Sammons, 2004/2005)
(Profile internationalisation code contributed by Andrea Giogini, 2005)


(All code released as public domain)


For more information on FirefoxADM, see http://ick2.wordpress.com

Most up-to-date documentation, see http://homepages.ed.ac.uk/mcs/FirefoxADM/ADM_Deploy.pdf


Instructions (also see documentation URL above):

(1)  Add Firefox MSI (not supplied) to Group Policy
(2)  Add firefox_login.vbs login script to Group Policy
(3)  Add firefoxdefaults.adm administrative template
(4)  Set required settings


A group policy with just the Adminstrative Template can be included
at any lower OU level and will override settings for any higher settings.


Contact me at:  mark.sammons@ed.ac.uk
with any bugs, ideas, queries, etc.


