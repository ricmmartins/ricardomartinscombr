FirefoxADM Startup 0.6
----------------------

(Code written by Mark Sammons, 2004/2005/2008/2009)
(File:// URL Security feature contributed by Michael Morandi)
(Delete Private Data Cookies, Delete Private Data Offline Websites, Delete Private Data Passwords, Show SSL Domain Icon, Use Download Directory, Replace Certificates for all User Profiles code by Florian Baenziger)
(Suppression of Firefox update page by Nathan Przybyszewski, 2009)


(All code released as public domain)


For more information on FirefoxADM, see http://ick2.wordpress.com

Most up-to-date documentation, see http://homepages.ed.ac.uk/mcs/FirefoxADM/ADM_Deploy.pdf


Instructions (also see documentation URL above):

(1)  Add Firefox MSI (not supplied) to Group Policy
(2)  Add firefox_startup.vbs startup script to Group Policy
(3)  Add firefoxlock.adm administrative template
(4)  Set required settings


A group policy with just the Adminstrative Template can be included
at any lower OU level and will override settings for any higher settings.


Contact me at:  mark.sammons@ed.ac.uk
with any bugs, ideas, queries, etc.

